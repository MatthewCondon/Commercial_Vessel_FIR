Maritime-N2K Wireshark Profile (Columns)

What it does
- Adds packet list columns that are more readable for CAN / NMEA2000 work:
  CAN ID, Ext flag, Length, PGN, Src, Dst, etc.

Import (recommended)
1) Open Wireshark
2) Edit -> Configuration Profiles...
3) Import...
4) Select the ZIP you downloaded, or select the profile folder

If some columns are blank
- Different dissectors use different field names.
- This profile includes both "nmea2000.*" and "nmea-2000.*" variants so at least one set should populate.
- If you don't have a NMEA2000 dissector enabled, only CAN columns will fill.

Tip
- After importing, switch to the profile via:
  Edit -> Configuration Profiles -> Maritime-N2K
